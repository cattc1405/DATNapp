import React from 'react';
import Profile from './src/Profile';


function App(): React.JSX.Element {
  return (
  <Profile/>
  );
}
export default App;

