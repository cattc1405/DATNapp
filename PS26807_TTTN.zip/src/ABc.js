import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const ABc = () => {
  return (
    <View>
      <Text>ABc</Text>
    </View>
  )
}

export default ABc

const styles = StyleSheet.create({})