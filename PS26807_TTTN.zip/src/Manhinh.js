import { StyleSheet, Text, View} from 'react-native';
import React from 'react';

const Manhinh = () => {
  return (
    <View>
      <View>
        <Text>abc</Text>
      </View>
    </View>
  );
};

export default Manhinh;

const styles = StyleSheet.create({

})